package com.duckii.skinchanger.client;

/**
 * Accessor interface to add skin button to TitleScreen
 */
public interface TitleScreenAccessor {
    void skinChanger$addSkinButton();
}