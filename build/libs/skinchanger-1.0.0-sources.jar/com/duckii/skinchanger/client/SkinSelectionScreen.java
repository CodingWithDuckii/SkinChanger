package com.duckii.skinchanger.client;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class SkinSelectionScreen extends class_437 {
    private static final int SKINS_PER_ROW = 3;
    private static final int BUTTON_WIDTH = 100;
    private static final int BUTTON_HEIGHT = 20;
    private static final int PADDING = 10;

    public SkinSelectionScreen() {
        super(class_2561.method_43471("gui.skinchanger.title"));
    }

    @Override
    protected void method_25426() {
        List<String> skins = SkinChangerClient.getSkins();
        int x = (this.field_22789 - (SKINS_PER_ROW * (BUTTON_WIDTH + PADDING))) / 2;
        int y = 50;

        for (int i = 0; i < skins.size(); i++) {
            final String skinUrl = skins.get(i);
            int row = i / SKINS_PER_ROW;
            int col = i % SKINS_PER_ROW;

            this.method_37063(class_4185.method_46430(class_2561.method_43470("Skin " + (i + 1)), button -> {
                SkinChangerClient.setCurrentSkinUrl(skinUrl);
            })
            .method_46434(x + col * (BUTTON_WIDTH + PADDING), y + row * (BUTTON_HEIGHT + PADDING), BUTTON_WIDTH, BUTTON_HEIGHT)
            .method_46431());
        }

        // Close button
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), button -> this.method_25419())
                .method_46434(this.field_22789 / 2 - 50, this.field_22790 - 40, 100, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
