package com.duckii.skinchanger.client;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class SkinSelectionScreen extends class_437 {
    private static final int BUTTON_WIDTH = 100;
    private static final int BUTTON_HEIGHT = 20;
    private String currentSkinName = "Default";

    public SkinSelectionScreen() {
        super(net.minecraft.class_2561.method_43470("Skin Changer"));
    }

    @Override
    protected void method_25426() {
        List<String> skins = SkinChangerClient.getSkins();
        int centerX = this.field_22789 / 2;
        int previewY = this.field_22790 / 2 - 70;

        // Add skin buttons on the right
        for (int i = 0; i < skins.size(); i++) {
            final String skinUrl = skins.get(i);
            String skinName = (i == 0) ? "Blob Duckie" : "Inverted";

            this.method_37063(class_4185.method_46430(net.minecraft.class_2561.method_43470(skinName), button -> {
                SkinChangerClient.setCurrentSkinUrl(skinUrl);
                currentSkinName = skinName;
            })
            .method_46434(centerX + 50, previewY + i * (BUTTON_HEIGHT + 10), BUTTON_WIDTH, BUTTON_HEIGHT)
            .method_46431());
        }

        // Remove skin button
        this.method_37063(class_4185.method_46430(net.minecraft.class_2561.method_43470("Remove Skin"), button -> {
            SkinChangerClient.setCurrentSkinUrl(null);
            currentSkinName = "Default";
        })
        .method_46434(centerX - 50 - BUTTON_WIDTH, previewY + (skins.size() + 1) * (BUTTON_HEIGHT + 10), BUTTON_WIDTH, BUTTON_HEIGHT)
        .method_46431());

        // Done button
        this.method_37063(class_4185.method_46430(net.minecraft.class_2561.method_43470("Done"), button -> this.method_25419())
                .method_46434(centerX - 50, previewY + (skins.size() + 2) * (BUTTON_HEIGHT + 10), BUTTON_WIDTH, BUTTON_HEIGHT)
                .method_46431());

        // Get current skin name
        updateCurrentSkinName();
    }

    private void updateCurrentSkinName() {
        String skinUrl = SkinChangerClient.getCurrentSkinUrl();
        if (skinUrl != null) {
            if (skinUrl.contains("blob")) {
                currentSkinName = "Blob Duckie";
            } else {
                currentSkinName = "Inverted";
            }
        } else {
            currentSkinName = "Default";
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Dark background
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xCC000000);

        int centerX = this.field_22789 / 2;
        int previewX = centerX - 64;
        int previewY = this.field_22790 / 2 - 70;

        // Draw title
        context.method_25300(this.field_22793, "Skin Changer", centerX, 20, 0xFFFFFF);
        context.method_25300(this.field_22793, "Select a skin:", centerX, 45, 0xAAAAAA);

        // Draw skin preview box (simulated with color)
        context.method_25294(previewX - 4, previewY - 4, previewX + 132, previewY + 132, 0xFF555555);
        context.method_25294(previewX, previewY, previewX + 128, previewY + 128, 0xFF333333);

        // Show current skin name in preview box
        if (currentSkinName.equals("Default")) {
            context.method_25300(this.field_22793, "Default", centerX, previewY + 56, 0xAAAAAA);
            context.method_25300(this.field_22793, "Steve/Alex", centerX, previewY + 72, 0xAAAAAA);
        } else {
            // Show colored name based on skin
            int color = currentSkinName.equals("Blob Duckie") ? 0xFF66CC : 0x00FFFF;
            context.method_25300(this.field_22793, currentSkinName, centerX, previewY + 56, color);
            context.method_25300(this.field_22793, "Skin", centerX, previewY + 72, color);
        }

        // Update skin name in real-time
        updateCurrentSkinName();

        // Show current skin status
        String currentSkin = SkinChangerClient.getCurrentSkinUrl();
        if (currentSkin != null) {
            String skinName = currentSkin.contains("blob") ? "Blob Duckie" : "Inverted";
            context.method_25300(this.field_22793, "Equipped: " + skinName, centerX, previewY + 140, 0x00FF00);
            context.method_25300(this.field_22793, "Click Done to Confirm", centerX, previewY + 156, 0xFFFF00);
        } else {
            context.method_25300(this.field_22793, "Equipped: Default Skin", centerX, previewY + 140, 0x888888);
            context.method_25300(this.field_22793, "No custom skin", centerX, previewY + 156, 0x888888);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }
}