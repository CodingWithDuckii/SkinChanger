package com.duckii.skinchanger.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class SkinChangerClient implements ClientModInitializer {
    private static String currentSkinUrl = null;
    private static final List<String> SKINS = new ArrayList<>();
    private static final Map<String, class_2960> DOWNLOADED_SKINS = new HashMap<>();
    private static class_304 openMenuKey;

    @Override
    public void onInitializeClient() {
        // Initialize skins
        SKINS.add("https://www.minecraftskins.com/uploads/skins/2026/04/15/blob-duckie-23995388.png?v951");
        SKINS.add("https://www.minecraftskins.com/uploads/skins/2026/01/24/inverted-23814924.png?v951");

        openMenuKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.skinchanger.open_menu",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                "category.skinchanger"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.method_1436()) {
                client.method_1507(new SkinSelectionScreen());
            }
        });
    }

    public static String getCurrentSkinUrl() {
        return currentSkinUrl;
    }

    public static void setCurrentSkinUrl(String url) {
        currentSkinUrl = url;
        if (url != null && !DOWNLOADED_SKINS.containsKey(url)) {
            downloadSkin(url);
        }
    }

    public static List<String> getSkins() {
        return SKINS;
    }

    public static class_2960 getSkinIdentifier(String url) {
        return DOWNLOADED_SKINS.get(url);
    }

    private static void downloadSkin(String urlString) {
        CompletableFuture.runAsync(() -> {
            try {
                URL url = new URL(urlString);
                try (InputStream is = url.openStream()) {
                    class_1011 image = class_1011.method_4309(is);
                    class_310.method_1551().execute(() -> {
                        class_2960 id = class_2960.method_60655("skinchanger", "skin_" + urlString.hashCode());
                        class_310.method_1551().method_1531().method_4616(id, new class_1043(image));
                        DOWNLOADED_SKINS.put(urlString, id);
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
