package com.duckii.skinchanger.mixin;

import com.duckii.skinchanger.client.SkinSelectionScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public abstract class GameMenuScreenMixin extends class_437 {
    protected GameMenuScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "initWidgets", at = @At("HEAD"))
    private void onInitWidgets(CallbackInfo ci) {
        // Add skin button to pause menu
        this.method_37063(class_4185.method_46430(class_2561.method_43470("👕"), button -> {
            this.field_22787.method_1507(new SkinSelectionScreen());
        })
        .method_46434(this.field_22789 / 2 + 104, this.field_22790 / 4 + 48 + -16, 20, 20)
        .method_46431());
    }
}