package com.duckii.skinchanger.mixin;

import com.duckii.skinchanger.client.SkinChangerClient;
import net.minecraft.class_2960;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerEntityMixin {
    @Inject(method = "getSkinTextures", at = @At("HEAD"), cancellable = true)
    private void onGetSkinTextures(CallbackInfoReturnable<class_8685> cir) {
        class_742 player = (class_742) (Object) this;
        
        // Only apply to the local player
        if (player.method_7340() && SkinChangerClient.getCurrentSkinUrl() != null) {
            // We need to return a SkinTextures object with our custom texture
            // For now, let's assume we have a way to get the Identifier for the URL
            class_2960 customSkinId = SkinChangerClient.getSkinIdentifier(SkinChangerClient.getCurrentSkinUrl());
            if (customSkinId != null) {
                class_8685 current = cir.getReturnValue();
                // If we don't have the current textures yet, we might need to wait or use defaults
                class_8685 customTextures = new class_8685(
                    customSkinId,
                    null, // textureUrl
                    null, // capeTexture
                    null, // elytraTexture
                    class_8685.class_7920.field_41123, // model
                    true // secure
                );
                cir.setReturnValue(customTextures);
            }
        }
    }
}
