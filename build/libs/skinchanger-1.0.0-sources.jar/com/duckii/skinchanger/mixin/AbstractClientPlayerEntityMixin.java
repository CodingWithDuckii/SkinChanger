package com.duckii.skinchanger.mixin;

import com.duckii.skinchanger.client.SkinChangerClient;
import net.minecraft.class_12079;
import net.minecraft.class_2960;
import net.minecraft.class_742;
import net.minecraft.class_7920;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerEntityMixin {
    @Inject(method = "getSkin", at = @At("HEAD"), cancellable = true)
    private void onGetSkin(CallbackInfoReturnable<class_8685> cir) {
        class_742 player = (class_742) (Object) this;

        // Only apply to the local player
        if (player.method_7340()) {
            // First check if Essential cosmetics has a skin override - respect Essential's cosmetics
            if (SkinChangerClient.isEssentialCosmeticsActive()) {
                class_2960 essentialSkin = SkinChangerClient.getEssentialSkinOverride();
                if (essentialSkin != null) {
                    // Essential has a cosmetic skin, let Essential handle it
                    return;
                }
            }

            // Then check if we have a custom skin selected
            if (SkinChangerClient.getCurrentSkinUrl() != null) {
                class_2960 customSkinId = SkinChangerClient.getSkinIdentifier(SkinChangerClient.getCurrentSkinUrl());
                if (customSkinId != null) {
                    // In 1.21.11, use SkinAssetInfo which implements TextureAsset
                    class_12079.class_12081 bodyTexture = new class_12079.class_12080(customSkinId, SkinChangerClient.getCurrentSkinUrl());
                    class_8685 customTextures = class_8685.method_74884(
                        bodyTexture,
                        null, // capeTexture
                        null, // elytraTexture
                        class_7920.field_41123 // model
                    );
                    cir.setReturnValue(customTextures);
                }
            }
        }
    }
}