package com.duckii.skinchanger.mixin;

import com.duckii.skinchanger.client.SkinSelectionScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_490;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_490.class)
public abstract class InventoryScreenMixin extends class_437 {
    protected InventoryScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void onInit(CallbackInfo ci) {
        int x = (this.field_22789 - 176) / 2;
        int y = (this.field_22790 - 166) / 2;
        
        this.method_37063(class_4185.method_46430(class_2561.method_43470("👕"), button -> {
            this.field_22787.method_1507(new SkinSelectionScreen());
        })
        .method_46434(x + 150, y + 60, 20, 20)
        .method_46431());
    }
}
